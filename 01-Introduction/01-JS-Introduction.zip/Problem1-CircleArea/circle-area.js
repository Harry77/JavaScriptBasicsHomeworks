function calcCircleArea(r) {
	var area = Math.PI * r * r;
	document.write(area);
}