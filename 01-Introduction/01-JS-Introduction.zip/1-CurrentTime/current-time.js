var currTime = new Date().toUTCString();
console.log(currTime);