var kmh = prompt("Enter value for km/h");

var knots = Number(kmh) * 0.539956803456;
knots = knots.toFixed(2);
console.log(knots);